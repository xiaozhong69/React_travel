import React from 'react';

export const SignInPage : React.FC = ()=>{
    return (
        <h1>登录页面</h1>
    )
}